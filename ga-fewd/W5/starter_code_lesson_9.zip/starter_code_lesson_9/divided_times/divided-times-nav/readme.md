Fonts Used
----------

http://www.google.com/fonts#UsePlace:use/Collection:PT+Serif:400,700,400italic,700italic|Old+Standard+TT:700

	font-family: 'PT Serif', serif;
	font-family: 'Old Standard TT', serif;


document.getElementById('celsius_to_farenheit').onclick = celsiusToFarenheit;
document.getElementById('farenheit_to_celsius').onclick = farenheitToCelsius;

var userInput = document.getElementById('temperature').value;

function farenheitToCelsius() {
    var celsius = (userInput - 32) / 1.8;
    document.getElementById('result').innerHTML = celsius + "\xb0C = " + userInput + "\xb0F";
};

function celsiusToFahrenheit() {
    var fahrenheit = 1.8 * userInput + 32;
    document.getElementByID('result').innerHTML = userInput + "\xb0C = " + fahrenheit + "\xb0F";
};
// when page is loaded: 
	//grab correct map data and render in the correct place

	// change current page in <nav> to class 'active'

	// map stay in place while descriptive content scrolls 

	// match .content and .container classes to correct eco class





// for mobile experience:
	// Switch to vertical layout (stacked vs side-by-side content)

	// colored 'layer navs' stack into narrow, full width bands
	// just below the header

	// resize map to allow touch-scrolling on the page, preventing
	// accidental pan interactions on touch 



// exploring the page
	// when user clicks on image thumbnail, it should take the
	// map's place in a fixed position aside text




// map interactions
	// default layer displayed should be the raw data for the 
	// data type being viewed 

	// Chicago wilderness boundaries displayed by default

	// the user can choose to swap raw data for analyzed 
	// geography (county? municipality? census tract?)

	// Zoom layers fixed to narrow range (dependent on
	// data development process)